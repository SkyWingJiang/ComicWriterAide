package module;

import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;

/**
 * ������⡣
 * @author Skywing
 */
public class KeyDetect
{
	/*��Ա*/
	private static boolean ctrl=false;
	private static boolean alt=false;
		
	/**
	 * ���ü���ߡ�
	 * @param detector Scene������ߡ�
	 */
	public static void setDetect(Scene detector)
	{
		detector.setOnKeyPressed(new EventHandler<KeyEvent>()
		{
			@Override
			public void handle(KeyEvent event) 
			{
				KeyCode keyCode=event.getCode();
				
				if(keyCode==KeyCode.CONTROL)
					ctrl=true;
				if(keyCode==KeyCode.ALT)
					alt=true;
			}			
		});
		detector.setOnKeyReleased(new EventHandler<KeyEvent>()
		{
			@Override
			public void handle(KeyEvent event)
			{
				KeyCode keyCode=event.getCode();
				
				if(keyCode==KeyCode.CONTROL)
					ctrl=false;
				if(keyCode==KeyCode.ALT)
					alt=false;
			}			
		});
	}
	
	/**
	 * ��ѯ���¡�
	 * @param keyCode KeyCode����ֵ��
	 * @return boolean
	 * 		true�����¡�
	 * 		false��δ���¡�
	 */
	public static boolean isPressed(KeyCode keyCode)
	{
		if(keyCode==KeyCode.CONTROL)
			return ctrl;
		else if(keyCode==KeyCode.ALT)
			return alt;
		else
			return false;
	}
}
