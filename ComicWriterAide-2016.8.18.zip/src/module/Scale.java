package module;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import application.Main;
import javafx.animation.AnimationTimer;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.ScrollEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.transform.Rotate;
import javafx.scene.transform.Translate;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import part.Icon;
import resource.Strings;

/**
 * �����ߡ�
 * @author Skywing��
 */
public class Scale extends Stage
{
	/*��Ա*/
	private Icon_Main icon_main;			//������
	private Icon_Active icon_active;		//�����
	private Icon_Line icon_line;			//��
	private Scene scene;
	private Group rootGroup;				//����
	private Group functionGroup;			//�����飬�����������
	private Run run;						//��������

	/**
	 * ���췽����
	 * @throws FileNotFoundException��
	 */
	public Scale() throws FileNotFoundException
	{
		super();
		
		functionGroup=new Group();
		
		rootGroup=new Group();		
		rootGroup.getChildren().add(functionGroup);
		
		scene=new Scene(rootGroup);
		scene.setFill(null);
		KeyDetect.setDetect(scene);		//���ð������
					
		icon_line=new Icon_Line();
		icon_main=new Icon_Main();		
		icon_active=new Icon_Active();
		
		initStyle(StageStyle.TRANSPARENT);		//����͸��
		setMaximized(true);						//���
		setAlwaysOnTop(true);					//ʼ��ǰ����ʾ
		setScene(scene);	
		initOwner(Main.primaryStage);
		
		run=new Run();
		
		functionGroup.getTransforms().add(new Translate(Main.ScreenWidth-Strings.WIDTH_ICON_MAIN,Main.ScreenHeight-Strings.HEIGHT_ICON_MAIN));		//��ʼλ�ã����½�
	}
	
	/**
	 * �򿪡�
	 */
	public void open()
	{
		show();
		run.start();
	}
	
	@Override
	public void hide()
	{
		super.hide();
		run.stop();
	}
	
	/**
	 * ���С�
	 * �ڲ��ࡣ
	 * @author Skywing��
	 */
	class Run extends AnimationTimer
	{
		int i=0;
		
		@Override
		public void handle(long arg0) 
		{
			icon_main.update();		//���λ�úͷ������
			icon_active.update();
			icon_line.update();
			
			Icon.clear();		//�����ִ�б�ʶ
		}	
	}
	
	/**
	 * ��������
	 * �ڲ��ࡣ
	 * @author Skywing��
	 */
	class Icon_Main extends Icon<ImageView>
	{
		/*��Ա*/
		private double tempX,tempY;
		
		/**
		 * ���캯����
		 * @param group Group���顣
		 * @throws FileNotFoundException��
		 */
		public Icon_Main() throws FileNotFoundException
		{
			super();
			
			node=new ImageView(new Image(new FileInputStream(Strings.PATH_ICON_SCALE_MAIN)));
			node.setOnMousePressed(new EventHandler<MouseEvent>()		//����϶�
			{
				@Override
				public void handle(MouseEvent event) 
				{				
					tempX=event.getX();		//�ƶ�������
					tempY=event.getY();
				}	
			});
			node.setOnMouseDragged(new EventHandler<MouseEvent>()
			{
				@Override
				public void handle(MouseEvent event) 
				{						
					translatingX=event.getX()-tempX;
					translatingY=event.getY()-tempY;
					
					updateFlag=true;
				}
			});
				
			functionGroup.getChildren().add(node);
		}
			
		@Override
		protected void update()
		{
			if(updateFlag)
			{
				if(translatingX!=0||translatingY!=0)
					node.getTransforms().add(new Translate(translatingX,translatingY));		
				if(rotatingAngle!=0)
					node.getTransforms().add(new Rotate(rotatingAngle,Strings.WIDTH_ICON_MAIN/2,Strings.HEIGHT_ICON_MAIN/2));		
			}
		}
	}

	/**
	 * �������
	 * �ڲ��ࡣ
	 * @author Skywing��
	 */ 
	class Icon_Active extends Icon<ImageView>
	{
		/*��Ա*/
		private double originX,originY;			//����Բ�㣬ĩ�˵�
		private double tempAngle;
		private double length;					//�߳���
		private double translatingLength;		//���仯����
		
		/**
		 * ���췽��
		 * @param group Group���顣
		 * @throws FileNotFoundException
		 */
		public Icon_Active() throws FileNotFoundException
		{	
			super();
			
			originX=Strings.WIDTH_ICON_ACTIVE/2;		//ԭ��Ϊ�������
			originY=Strings.WIDTH_ICON_ACTIVE/2;
			length=0;
			translatingLength=0;
			
			node=new ImageView(new Image(new FileInputStream(Strings.PATH_ICON_SCALE_ACTIVE)));
			node.setOnMousePressed(new EventHandler<MouseEvent>()		//��ת
			{
				@Override
				public void handle(MouseEvent event) 
				{
					double x=event.getX()-originX;
					double y=event.getY()-originY;
					double radian=Math.atan((y)/(x));
					if(x<0&&y>=0)
						radian=Math.PI+radian;
					else if(x<0&&y<0)
						radian=-Math.PI+radian;
					
					tempAngle=Math.toDegrees(radian);		//תת������
				}	
			});
			node.setOnMouseDragged(new EventHandler<MouseEvent>()
			{
				@Override
				public void handle(MouseEvent event) 
				{
					double x=event.getX()-originX;
					double y=event.getY()-originY;
					double radian=Math.atan(y/x);
					if(x<0&&y>=0)
						radian=Math.PI+radian;
					else if(x<0&&y<0)
						radian=-Math.PI+radian;
					
					rotatingAngle=Math.toDegrees(radian)-tempAngle;
					
					updateFlag=true;
				}
			});
			
			scene.setOnScroll(new EventHandler<ScrollEvent>()		//������
			{
				static final double SCROLLSTEP=8;		//���ι���length�仯��
				
				@Override
				public void handle(ScrollEvent event) 
				{
					if(KeyDetect.isPressed(KeyCode.CONTROL))		//��ѯ����Ctrl�Ƿ��¡����ǣ��ı��߶���
						icon_line.setSegment(event.getDeltaY()>0);
					else		//�����ǣ��ı��߳���
					{
						if(translatingLength==0)
						{
							if(event.getDeltaY()>0)
							{
								length+=SCROLLSTEP;
								translatingLength=SCROLLSTEP;
							}
							else if(length>0)
							{
								length-=SCROLLSTEP;
								translatingLength=-SCROLLSTEP;
							}
						
							originX=-length+Strings.WIDTH_ICON_ACTIVE/2;
						}
					}
					
					updateFlag=true;
				}			
			});
			
			functionGroup.getChildren().add(node);
		}

		@Override
		protected void update() 
		{	
			if(updateFlag)
			{
				if(rotatingAngle!=0)
					node.getTransforms().add(new Rotate(rotatingAngle,originX,originY));		
				if(translatingX!=0||translatingY!=0)
					node.getTransforms().add(new Translate(translatingX,translatingY));
				if(translatingLength!=0)
					node.getTransforms().add(new Translate(translatingLength,0));
				
				translatingLength=0;
			}
		}
	}

	/**
	 * ����������
	 * �ڲ��ࡣ
	 * @author Skywing
	 */
	class Icon_Line extends Icon<Line>
	{
		/*��Ա*/
		private double startX;		//���
		private double startY;
		private double endX;		//�յ�
		private double endY;
		private int segment;		//����
		private Group dots;
		
		/**
		 * ���췽��
		 * @param group Group���顣
		 */
		public Icon_Line()
		{
			startX=0;
			startY=0;
			endX=0;
			endY=0;
			segment=1;
			
			node=new Line();
			node.setStroke(Color.RED);
			
			dots=new Group();
			
			functionGroup.getChildren().add(node);
			functionGroup.getChildren().add(dots);
		}

		@Override
		protected void update() 
		{
			if(updateFlag)
			{
				startX=icon_main.getX();
				startY=icon_main.getY();		
				endX=icon_active.getX();
				endY=icon_active.getY();
				
				node.setStartX(startX);
				node.setStartY(startY);	
				node.setEndX(endX);
				node.setEndY(endY);
				
				dots.getChildren().clear();
				for(int i=1;i<=segment;i++)
					drawDot(startX+(endX-startX)*i/segment,startY+(endY-startY)*i/segment);	
			}
		}
		
		/**
		 * ���㡣
		 * ����ǰ�����Group dots�����ݡ�
		 * @param x double�������ꡣ
		 * @param y double�������ꡣ
		 */
		private void drawDot(double x,double y)
		{		
			Circle circle=new Circle(x,y,4);
			circle.setFill(Color.RED);
			circle.setStroke(Color.RED);
			
			dots.getChildren().add(circle);
		}
		
		/**
		 * �趨������
		 * @param segment int��������
		 */
		public void setSegment(boolean direction)
		{
			if(direction&&segment<64)
				segment++;
			else if(!direction&&segment>1)
				segment--;
		}
	}
}
