package module;

import java.awt.AWTException;
import java.awt.Image;
import java.awt.Menu;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import application.Main;
import javafx.application.Platform;
import resource.Strings;

/**
 * ϵͳ����
 * @author Skywing
 */
public class Tray
{
	/*����*/
	private static final int SCALE=0;
	private static final int COLORPICKER=1;
	public static final String MESSAGE_SCALE_OPEN="MESSAGE_SCALE_OPEN";						//��Ϣ���򿪱�����
	public static final String MESSAGE_SCALE_CLOSE="MESSAGE_SCALE_CLOSE";					//��Ϣ���رձ�����
	public static final String MESSAGE_COLORPICKER_OPEN="MESSAGE_COLORPICKER_OPEN";			//��Ϣ����ȡɫ��
	public static final String MESSAGE_COLORPICKER_CLOSE="MESSAGE_COLORPICKER_CLOSE";		//��Ϣ����ȡɫ��
	public static final String MESSAGE_EXIT="MESSAGE_EXIT";
	/*��Ա*/
	private SystemTray systemTray;			//ϵͳ����			
	private PopupMenu menu;					//���˵�
	private boolean state_scale;			//������״̬
	private boolean state_colorPicker;		//ȡɫ��״̬
	
	public Tray() throws AWTException, IOException
	{
		systemTray=SystemTray.getSystemTray();
		state_scale=false;
		state_colorPicker=false;
		
		MenuItem menuItem_close=new MenuItem(Strings.MENUITEM_EXIT);		//�˵���˳�	
		menuItem_close.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e) 
			{		
				Platform.runLater(new Runnable()
				{
					@Override
					public void run() 
					{
						if(Main.scale!=null)
							Main.scale.hide();
						if(Main.colorPicker!=null)
							Main.colorPicker.hide();
						
						System.exit(0);
					}						
				});
			}
		});
		
		Menu submenu_scale=new Menu(Strings.NAME_SCALE);		//�Ӳ˵���������
		MenuItem menuItem_scale_open=new MenuItem(Strings.MENUITEM_OPEN);
		MenuItem menuItem_scale_demonstration=new MenuItem(Strings.MENUITEM_DEMONSTRATION);
		submenu_scale.add(menuItem_scale_open);
		submenu_scale.add(menuItem_scale_demonstration);
		menuItem_scale_open.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				if(!state_scale)
				{
					state_scale=true;
					Platform.runLater(new Runnable()		//��JavaFX�߳�������
					{
						@Override
						public void run() 
						{
							try
							{
								if(Main.scale==null)		//����һ�δ򿪣��򴴽�����
									Main.scale=new Scale();								
								Main.scale.open();
							}catch (FileNotFoundException e){e.printStackTrace();}
						}						
					});
				}
				else
				{
					state_scale=false;
					Platform.runLater(new Runnable()
					{
						@Override
						public void run() 
						{
							if(Main.scale!=null)
								Main.scale.hide();
						}						
					});
				}
			}
		});	
		menuItem_scale_demonstration.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				demonstration(SCALE);
			}		
		});
		
		Menu submenu_colorPicker=new Menu(Strings.NAME_COLORPICKER);		//�Ӳ˵���ȡɫ��
		MenuItem menuItem_colorPicker_open=new MenuItem(Strings.MENUITEM_OPEN);
		MenuItem menuItem_colorPicker_demonstration=new MenuItem(Strings.MENUITEM_DEMONSTRATION);
		submenu_colorPicker.add(menuItem_colorPicker_open);
		submenu_colorPicker.add(menuItem_colorPicker_demonstration);
		menuItem_colorPicker_open.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				if(!state_colorPicker)
				{
					state_colorPicker=true;
					Platform.runLater(new Runnable()
					{
						@Override
						public void run() 
						{
							try
							{
								if(Main.colorPicker==null)
									Main.colorPicker=new ColorPicker();								
								Main.colorPicker.open();
							}catch (IOException|AWTException e){e.printStackTrace();}
						}						
					});
				}
				else
				{
					state_colorPicker=false;
					Platform.runLater(new Runnable()
					{
						@Override
						public void run() 
						{
							if(Main.colorPicker!=null)
								Main.colorPicker.hide();
						}						
					});
				}
			}
		});	
		menuItem_colorPicker_demonstration.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				demonstration(COLORPICKER);
			}		
		});
		
		menu=new PopupMenu();		//���̲˵�
		menu.add(submenu_scale);
		menu.add(submenu_colorPicker);
		menu.addSeparator();
		menu.add(menuItem_close);
	
		Image trayImage=ImageIO.read(new File(Strings.PATH_ICON_TRAY));		//����ͼ�����ʾ����
		TrayIcon trayIcon=new TrayIcon(trayImage,Strings.NAME_APPLICATION,menu);
		trayIcon.setImageAutoSize(true);
		systemTray.add(trayIcon);	
	}
	
	/**
	 * ��ʾ˵����Ϣ��
	 * @param which int�������
	 */
	public void demonstration(int which)
	{
		String path=new String();
		String module=new String();
		
		switch(which)
		{
		case SCALE:
			path=Strings.PATH_HELP_SCALE;		//˵���ļ���ַ
			module=Strings.NAME_SCALE;			//�������
			
			break;
		case COLORPICKER:
			path=Strings.PATH_HELP_COLORPICKER;
			module=Strings.NAME_COLORPICKER;
			
			break;
		default:
			break;
		}
		
		try		
		{
			String helpInformation=new String();			
			Scanner scanner=new Scanner(new File(path));
			while(scanner.hasNextLine())
			{
				String string=scanner.nextLine();
				helpInformation+=string;
				helpInformation+="\n";
			}
			scanner.close();
			
			String string=Strings.MENUITEM_DEMONSTRATION+" - "+module;
			JOptionPane.showMessageDialog(null,helpInformation,string,JOptionPane.INFORMATION_MESSAGE);
		} catch (FileNotFoundException e1){e1.printStackTrace();}	
	}
}

