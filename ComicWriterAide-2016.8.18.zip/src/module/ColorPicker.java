package module;

import java.awt.AWTException;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.Robot;
import java.io.IOException;
import java.net.URL;
import application.Main;
import javafx.animation.AnimationTimer;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.transform.Translate;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import part.Controller_ColorPicker;
import resource.Strings;

/**
 * ȡɫ����
 * @author Skywing
 */
public class ColorPicker extends Stage
{
	/*����*/
	private static final int WIDTH=270;		//�������
	private static final int HEIGHT=270;	//����߶�
	/*��Ա*/
	private Scene scene;
	private Group rootGroup;						//����
	private AnchorPane functionGroup;				//�����飬�����������
	private Controller_ColorPicker controller;		//���ֿ�����	
	private Run run;								//��������
	private Robot robot;							//��Ļ������ȡ������
	private double tempX,tempY;
	private double translatingX,translatingY;
	
	/**
	 * ���췽����
	 * @throws IOException
	 * @throws AWTException 
	 */
	public ColorPicker() throws IOException, AWTException
	{		
		String stringUrl=Strings.PATH_LAYOUT_COLORPICKER;		//String��ַת��ΪURL		
		URL fxmlUrl=this.getClass().getClassLoader().getResource(stringUrl);		
		FXMLLoader fxmlLoader=new FXMLLoader();		//��������
		fxmlLoader.setLocation(fxmlUrl);
		functionGroup=fxmlLoader.<AnchorPane>load();
		functionGroup.getTransforms().add(new Translate(Main.ScreenWidth-WIDTH,Main.ScreenHeight-HEIGHT));		//��ʼλ��
		controller=fxmlLoader.getController();		//��ȡ���ֿ�����	
		functionGroup.setOnMousePressed(new EventHandler<MouseEvent>()		//��������϶�
		{
			@Override
			public void handle(MouseEvent event) 
			{				
				tempX=event.getX();
				tempY=event.getY();
			}	
		});
		functionGroup.setOnMouseDragged(new EventHandler<MouseEvent>()
		{
			@Override
			public void handle(MouseEvent event) 
			{						
				translatingX=event.getX()-tempX;
				translatingY=event.getY()-tempY;
			}
		});
		
		rootGroup=new Group();
		rootGroup.getChildren().add(functionGroup);	
		scene=new Scene(rootGroup,Main.ScreenWidth,Main.ScreenWidth);	
		scene.setFill(null);
		KeyDetect.setDetect(scene);		//���ü��̼��
		
		robot=new Robot();
		run=new Run();
		
		setMaximized(true);
		initStyle(StageStyle.TRANSPARENT);
		setResizable(false);
		setAlwaysOnTop(true);
		setScene(scene);
		initOwner(Main.primaryStage);
	}

	/**
	 * ���С�
	 * �ڲ��ࡣ
	 * @author Skywing��
	 */
	class Run extends AnimationTimer
	{
		@Override
		public void handle(long arg0) 
		{
			if(translatingX!=0||translatingY!=0)		//�����ƶ�
				functionGroup.getTransforms().add(new Translate(translatingX,translatingY));
			else
			{
				Point mousePoint=MouseInfo.getPointerInfo().getLocation();		//��ȡ�������λ��������ɫ��Ϣ		
				java.awt.Color pixel=robot.getPixelColor(mousePoint.x,mousePoint.y);
				int red=pixel.getRed();
				int green=pixel.getGreen();
				int blue=pixel.getBlue();
				
				controller.setSelectColor(red,green,blue);		//����ѡ������ɫ
				
				if(KeyDetect.isPressed(KeyCode.ALT))		//��������ɫ����
					controller.lockColor();	
			}
			
			translatingX=0;
			translatingY=0;
		}	
	}
	
	/**
	 * �򿪡�
	 */
	public void open()
	{
		show();
		run.start();		
	}
	
	@Override
	public void hide()
	{
		super.hide();
		run.stop();
	}
}
