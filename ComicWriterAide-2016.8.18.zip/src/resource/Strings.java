package resource;

/**
 * ��Դ
 * 
 * @author Skywing
 *
 */
public class Strings {
	/* ·�� */
	public static final String PATH_ICON = "./Icon";
	public static final String PATH_ICON_TRAY = PATH_ICON + "/Icon.png";
	public static final String PATH_ICON_SCALE_MAIN = PATH_ICON + "/Scale_Main.png";
	public static final String PATH_ICON_SCALE_ACTIVE = PATH_ICON + "/Scale_Active.png";
	public static final String PATH_HELP = "./Help";
	public static final String PATH_HELP_SCALE = PATH_HELP + "/Scale.txt";
	public static final String PATH_HELP_COLORPICKER=PATH_HELP+"/ColorPicker.txt";
	public static final String PATH_LAYOUT_COLORPICKER="./resource/Layout_ColorPicker.fxml";

	/* ���� */
	public static final int WIDTH_ICON_MAIN = 100;
	public static final int HEIGHT_ICON_MAIN = 100;
	public static final int WIDTH_ICON_ACTIVE = 100;
	public static final int HEIGHT_ICON_ACTIVE = 100;

	/* �ַ��� */
	public static final String NAME_APPLICATION = "����������";
	public static final String NAME_SCALE = "������";
	public static final String NAME_COLORPICKER = "ȡɫ��";
	public static final String MENUITEM_OPEN = "��";
	public static final String MENUITEM_HIDE = "����";
	public static final String MENUITEM_DEMONSTRATION = "˵��";
	public static final String MENUITEM_EXIT = "�˳�";
}
