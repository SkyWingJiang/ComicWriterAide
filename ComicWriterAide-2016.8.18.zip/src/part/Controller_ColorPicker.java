package part;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

/**
 * ȡɫ�����ֿ�������
 * @author Skywing
 */
public class Controller_ColorPicker
{
	/*��Ա*/
	@FXML public Rectangle rectangle_selectColor;
	@FXML public Rectangle rectangle_lockColor;
	@FXML public Label label_selectColor_r;
	@FXML public Label label_selectColor_g;
	@FXML public Label label_selectColor_b;
	@FXML public Label label_lockColor_r;
	@FXML public Label label_lockColor_g;
	@FXML public Label label_lockColor_b;
	
	/**
	 * ����ѡ������ɫ��
	 * @param red int����ɫ������0~255��
	 * @param green int����ɫ������0~255��
	 * @param blue int����ɫ������0~255��
	 */
	public void setSelectColor(int red,int green,int blue)
	{
		label_selectColor_r.setText(Integer.toString(red));
		label_selectColor_g.setText(Integer.toString(green));
		label_selectColor_b.setText(Integer.toString(blue));	
		
		rectangle_selectColor.setFill(new Color((double)red/255,(double)green/255,(double)blue/255,1));
	}
	
	/**
	 * ������ɫ
	 */
	public void lockColor()
	{
		label_lockColor_r.setText(label_selectColor_r.getText());
		label_lockColor_g.setText(label_selectColor_g.getText());
		label_lockColor_b.setText(label_selectColor_b.getText());
		
		rectangle_lockColor.setFill(rectangle_selectColor.getFill());
	}
}